var md5 = require('md5');
var user = {};
var User = require('../models/user');

user.index = function(req,res){

  if(!req.session.uniqueID){
	  res.render('index',{
	    title:"Login"
	  });
	}else{
		res.redirect('/admin');
	}
    return;
}

user.loginAction = function(req,res){
  req.checkBody('login','Login is required').notEmpty();
  req.checkBody('password','Password is required').notEmpty();
  errors = req.validationErrors();
  if ( errors ) {
    res.render('index',{
      title:"Login",
      errors:errors
    });
  }else{
    var data = [];
    data.push(req.body.login);
    data.push(md5(req.body.password));

    User.checkUser(data,function(err,result) {
      if(err || result == null){
        errors = [{msg:"Wrong login or password"}];
        res.render('index',{
          title:"Login",
          errors:errors
        });
      }else{
        req.session.uniqueID = md5(result[0].password);

        if(result[0].role === 'admin'){
            return res.redirect('/admin');
        }else if(result[0].role === 'manager'){
            return res.redirect('/manager');
        }
      }
    });
  }
}

user.logout = function(req,res){
  req.session.destroy(function(error){
		res.redirect('/');
	})
}

module.exports = user;
