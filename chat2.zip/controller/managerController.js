var Rates = require('../models/rate');
var User = require('../models/user');

// Display list of all Configs
exports.commentsList = function(req, res) {
    User.authenticate(req,res);
    Rates.getDriverComments(function(err,rates){
      if(err || rates == null){
  			console.log(err);
  		}else {
        res.render('rates',{
      		title:"Մեկնաբանություններ",
          rates:rates
      	});
      }
    })
};

exports.deleteComment = function(req,res){
  User.authenticate(req,res);
  var rate = req.body.rate_id;
	if (rate){
		Rates.deleteRate([rate],function(err,result){
				if (err){
					errors= [{msg:err}];
					res.render('rates',{
						title:"Մեկնաբանություններ",
						errors:errors
					});
				}else if(result){
					res.redirect('/driver/rates');
				}
		});
	}
}
