var Config = require('../models/config');
var User = require('../models/user');

// Display list of all Configs
exports.configsList = function(req, res) {
    User.authenticate(req,res);
    Config.getConfigs(function(err,configs){
      if(err || configs == null){
  			console.log(err);
  		}else {
        res.render('config',{
      		title:"Կարգավորումներ",
          config:configs
      	});
      }
    });
};

exports.editConfigData = function(req,res){
  User.authenticate(req,res);
  var data = [{
    min_price:req.body.min_price,
    price_for_km:req.body.price_for_km,
  }];

  Config.editConfig(data,function(err,result){
    if (err){
      errors= [{msg:err}];
      console.log(errors);
    }else if(result){
      res.redirect('/driver/configs');
    }
  });
}
