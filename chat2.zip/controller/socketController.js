var Driver = require('../models/driver');
var cars = null;
Driver.getCarsData((err,data) =>{
  if(err || data == null){
    console.log(err);
  }else {
    cars = data;
  }
});

module.exports = function(io){
  io.on('connection', function (socket) {
      socket.broadcast.emit('lt_v1_cars_broadcast', JSON.stringify(cars));
      // When the server receives a “message” type signal from the client
      socket.on('lt_v1_cars_broadcast', function (message) {
          socket.broadcast.emit('lt_v1_cars_broadcast', JSON.stringify(cars));
      });
  });
}
