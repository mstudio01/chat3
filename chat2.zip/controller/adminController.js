var User = require('../models/user');
var md5 = require('md5');

exports.index = function(req,res){
  User.authenticate(req,res);
  User.getAllUsers(function(err,data){
		if(err || data == null){
			console.log(err);
		}else {
			res.render('users',{
				title:"",
				users:data,
                'active':''
			})
		}
	});
}

exports.company = function(req,res){
  User.authenticate(req,res);
	res.render('company',{'active':'company'});
}

exports.education = function(req,res){
    User.authenticate(req,res);
    res.render('education',{'active':'education'});
}

exports.appliance = function(req,res){
    User.authenticate(req,res);
    res.render('appliance',{'active':'appliance'});
}

exports.roles = function(req,res){
    User.authenticate(req,res);
    res.render('roles',{'active':'role'});
}

exports.addUserAction = function(req,res){
  // User.authenticate(req,res);
	// req.checkBody('phone','Հեռախոսի համարը պարտադիր է լրացման համար').notEmpty();
	// req.checkBody('password','Գաղտնաբառը պարտադիր է լրացման համար').notEmpty();
	// req.checkBody('password','Գաղտնաբառը պետք է պարունակի առնվազն 8 նիշ').len(8, 20);
	// req.checkBody('email','Էլ.հասցեն չի համապատասխանում համապատասխան ֆորմատին').isEmail();
	// errors = req.validationErrors();
  // if ( req.body.password != req.body.confirm_password ){
  //   errors.push({msg:"Գաղտնաբառերը չեն համապատասխանում"});
  // }
  // var patt = new RegExp(/^[\+]?[+(]?[0-9]{3}[)]?[0-9]{8}$/);
	// var isValid =  patt.test(req.body.phone);
	// if ( ! isValid ) {
  //   errors.push({msg:"Հեռախոսահամարը չի համապատասխանում նախատեսված ֆորմատին"});
	// 	res.render('driver_add',{
	// 		title:"Ավելացնել նոր վարորդ",
	// 		errors:errors
	// 	});
	// 	return false;
	// }
	// if ( errors ) {
	// 	res.render('driver_add',{
	// 		title:"Ավելացնել նոր վարորդ",
	// 		errors:errors
	// 	});
	// }else{
	// 	var data = [];
  //   console.log(req.file);
	// 	if ( req.file ){
	// 		var avatar = req.file.filename;
	// 	}	else{
	// 		var avatar = "";
	// 	}
	// 	data.push(req.body.firstname);
	// 	data.push(req.body.lastname);
	// 	data.push(req.body.phone);
	// 	data.push(req.body.email);
	// 	data.push(md5(req.body.password));
	// 	data.push(avatar);
	// 	data.push(req.body.address);
	// 	data.push('driver');
	// 	Driver.addNewDriver(data,function(err,result){
	// 			if (err){
	// 				errors= [{msg:err}];
	// 				res.render('driver_add',{
	// 					title:"Ավելացնել նոր վարորդ",
	// 					errors:errors
	// 				});
	// 			}else if(result){
	// 				res.redirect('/driver/profile');
	// 			}
	// 	});
	// }
}

exports.editUser  = function(req,res){
  User.authenticate(req,res);
	var driverID = req.params.driver_id;
	if ( driverID ){
		Driver.driverByID(driverID,function(err,result){
			if(err){
				console.log(err);
			}else {
				res.render('driver_edit',{
					title:"Խմբագրել Վարորդի տվյալները",
					driver:result[0]
				});
			}
		});
	}
}

exports.editUserAction = function(req,res){
  User.authenticate(req,res);
	var driverID = req.body.driver_id;
	if ( ! driverID ){
		res.redirect("/driver/profile");
	}
	Driver.driverByID(driverID,function(err,result){
		if(err){
		}else {
			var patt = new RegExp(/^[\+]?[+(]?[0-9]{3}[)]?[0-9]{8}$/);
	  	var isValid =  patt.test(req.body.phone);
			if ( ! isValid ) {
        errors.push({msg:"Հեռախոսահամարը չի համապատասխանում նախատեսված ֆորմատին"});
				res.render('driver_edit',{
					title:"Խմբագրել Վարորդի տվյալները",
					errors:errors,
					driver:result[0]
				});
				return false;
			}
			req.checkBody('phone','Phone is required').notEmpty();
			req.checkBody('email','Էլ.հասցեն չի համապատասխանում նախատեսված ֆորմատին').isEmail();
			errors = req.validationErrors();
			if ( req.body.password != req.body.confirm_password ){
				  errors.push({msg:"Գաղտնաբառերը չեն համապատասխանում"});
			}
			if ( errors ) {
				res.render('driver_edit',{
					title:"Խմբագրել Վարորդի տվյալները",
					errors:errors,
					driver:result[0]
				});
			}else{
				if ( req.file ){
					var avatar = req.file.filename;
				}	else{
					avatar = result[0].avatar;
				}

				if ( req.body.password == '' ){
					var password = result[0].password;
				}else{
					var password = md5(req.body.password);
				}
				var data = [{
					firstname:req.body.firstname,
					lastname:req.body.lastname,
					phone:req.body.phone,
					email:req.body.email,
					password:password,
					avatar:avatar,
					address:req.body.address
				},req.body.driver_id];
				Driver.editDriver(data,function(err,result){
						if (err){
							errors= [{msg:err}];
							res.render('driver_edit',{
								title:"Խմբագրել Վարորդի տվյալները",
								errors:errors,
								driver:result[0]
							});
						}else if(result){
							//console.log(avatar);
							res.redirect('/driver/profile');
						}
				});
			}
		}
	});
}

exports.deleteUser = function(req,res){
  User.authenticate(req,res);
	var driver = req.body.user_id;
	if (driver){
		Driver.deleteDriver([driver],function(err,result){
				if (err){
					errors= [{msg:err}];
					res.render('drivers',{
						title:"Վարորդների ցանկ",
						errors:errors
					});
				}else if(result){
					res.redirect('/driver/profile');
				}
		});
	}
}
