var db = require('../db'),config = {};
var connection = db.getConnection();

config.getConfigs = function(callback){
	connection.query('SELECT * FROM config', function(err, rows) {
		if (err){
			callback(err,false);
		}else{
			callback(null,rows);
		}
  });
}
config.editConfig = function(data,callback) {
	connection.query('UPDATE config SET ?', data, function(err, rows) {
		if (err){
			callback(err,false);
		}else{
			callback(null,true);
		}
  });
}

module.exports = config;
