var db = require('../db'),rate = {};
var connection = db.getConnection();

rate.getDriverComments = function(callback) {
	connection.query("SELECT r.*, CONCAT(d.`firstname`,' ',d.`lastname`) AS driver_name,CONCAT(u.`firstname`,' ',u.`lastname`) AS commenter FROM rate r INNER JOIN users d ON d.`id` = r.`driver_id` AND d.`type` = 'driver' INNER JOIN users u ON u.`id` = r.`user_id` AND u.`type` = 'user'",function(err,rows){
		if (err){
			callback(err,false);
		}else{
			callback(null,rows);
		}
	})
}
rate.deleteRate = function(rateID,callback){
  connection.query('DELETE FROM rate WHERE id = ?', rateID, function(err, rows)  {
		if (err){
			callback(err,false);
		}else{
			callback(null,true);
		}
  })
}

module.exports = rate;
