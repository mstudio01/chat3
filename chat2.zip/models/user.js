var db = require('../db'),config = {};
var connection = db.getConnection();
var user = {};

user.authenticate = function(req,res){
    if(!req.session.uniqueID){
        return res.redirect('/');
    }
}

user.checkUser = function(data,callback)  {
  connection.query('SELECT * FROM users WHERE `login` = ? AND `password` = ?', data, function(err, rows,fields) {
		if (err || rows.length <= 0 ){
      callback(err,null);
    }else{
		callback(null,rows);
	}
  })
}

user.getAllUsers = function(callback) {
    connection.query("SELECT * FROM users ; ",function(error,rows,fields){
        if(error){
            callback(error,null);
        }else{
            callback(null,rows)
        }
    });
}

user.userByID = function(userId,callback) {
    connection.query('SELECT * FROM users WHERE id = ?', userId, function(err, rows,fields) {
        if (err || rows.length <= 0 ){
            callback(err,null);
        }else{
            callback(null,rows);
        }
    })
}

user.addNewUser = function(data,callback) {
    connection.query('INSERT INTO users (`firstname`,`lastname`,`phone`,`email`,`password`,`avatar`,`address`,`type`) VALUES (?)',[data], function(err, rows) {
        if (err){
            callback(err,null);
        }else{
            callback(null,true);
        }
    })
}

user.editUser = function(data,callback){
    connection.query('UPDATE users SET ? WHERE id= ?', data, function(err, rows)  {
        if (err){
            callback(err,false);
        }else{
            callback(null,true);
        }
    });
}

user.deleteUser = function(userId,callback){
    connection.query('DELETE FROM users WHERE id = ?', userId, function(err, rows) {
        if (err){
            callback(err,false);
        }else{
            callback(null,true);
        }
    })
}

module.exports = user;
