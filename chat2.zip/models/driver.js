var db = require('../db'),driver = {};
var connection = db.getConnection();

driver.getAllDrivers = function(callback) {
	connection.query("SELECT * FROM users WHERE `type`= 'driver'; ",function(error,rows,fields){
		if(error){
			callback(error,null);
    }else{
	    callback(null,rows)
    }
  });
}

driver.driverByID = function(userId,callback) {
  connection.query('SELECT * FROM users WHERE id = ?', userId, function(err, rows,fields) {
		if (err || rows.length <= 0 ){
      callback(err,null);
    }else{
			callback(null,rows);
		}
  })
}

driver.addNewDriver = function(data,callback) {
  connection.query('INSERT INTO users (`firstname`,`lastname`,`phone`,`email`,`password`,`avatar`,`address`,`type`) VALUES (?)',[data], function(err, rows) {
			if (err){
				callback(err,null);
			}else{
				callback(null,true);
			}
    })
}

driver.editDriver = function(data,callback){
  connection.query('UPDATE users SET ? WHERE id= ?', data, function(err, rows)  {
		if (err){
			callback(err,false);
		}else{
			callback(null,true);
		}
  });
}

driver.deleteDriver = function(userId,callback){
  connection.query('DELETE FROM users WHERE id = ?', userId, function(err, rows) {
		if (err){
			callback(err,false);
		}else{
			callback(null,true);
		}
  })
}

driver.getCarsData = function(callback){
	var result = null;
	connection.query("SELECT c.*,concat(u.`firstname`,' ',u.`lastname`) AS driver_name FROM cars c INNER JOIN users u ON u.`id` = c.`driver_id` AND u.`type` = 'driver'; ",function(error,rows,fields){
		if(error){
			callback(error,null);
    }else{
			result = rows;
	    callback(null,rows)
    }
  });
	return result;
}

module.exports = driver;
