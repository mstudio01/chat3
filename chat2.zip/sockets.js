var socketController = require('./controller/socketController');
module.exports = socketController;
