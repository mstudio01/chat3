$(document).ready(function () {
    $('.open-drop-down').click(function () {
        $('.drop-down-list').toggleClass('opened');
    });
    $('.modal-open').click(function(){
        var modal = $(this).attr('data-modal');
        $('#'+modal).show();
    });

    $('.menu-item').click(function () {
        $('.menu-item').removeClass('active');
        $(this).addClass('active');
    });
    $('.close-modal').click(function () {
        $(this).parent().find('input,select').val('');
        $(this).parent().hide();
    });
    $('.pagination .drop-down-icon').click(function () {
        $('.per-page-drop-down').slideToggle();
    });
    $(document).on('click','.pagination .per-page-drop-down ul li',function () {
        $('.selector-per-page').text($(this).attr('data-count'));
    });

    $('#login-user').submit(function (e) {
        e.preventDefault();
        e.stopPropagation();

        var login = $('input[name=login]').val();
        var pass = $('input[name=password]').val();
        var isValid = true;
        if( login == '' || login == undefined || login == null){
            isValid = false;
            $('input[name=login]').addClass('error');
        }else{
            $('input[name=login]').removeClass('error');
        }

        if( pass == '' || pass == undefined || pass == null){
            isValid = false;
            $('input[name=password]').addClass('error');
        }else{
            $('input[name=password]').removeClass('error');
        }

        if(isValid){
            $('#login-user').submit();
        }

    })
});