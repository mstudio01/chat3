var express = require('express');
var router = express.Router();

var adminController = require('../controller/adminController');

router.get('/',adminController.index);
router.get('/company',adminController.company);
router.get('/education',adminController.education);
router.get('/roles',adminController.roles);
router.get('/appliance',adminController.appliance);

router.post('/add-new-user',adminController.addUserAction);
router.post('/edit-user',adminController.editUserAction);
router.post('/delete-user',adminController.deleteUser);

module.exports = router;
