var express = require('express');
var router = express.Router();

var multer  = require('multer');
var upload = multer({ dest: './public/images/uploads/' });
var managerController = require('../controller/managerController');


module.exports = router;
