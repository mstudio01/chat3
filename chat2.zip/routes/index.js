var express = require('express');
var router = express.Router();

var loginController = require('../controller/loginController');
router.get('/',loginController.index);
router.post('/login',loginController.loginAction);
router.get('/logout',loginController.logout);

module.exports = router;
