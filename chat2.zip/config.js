var config = {
  host:'127.0.0.1',
  port:3000,
  db:{
    username:'root',
    pwd:'',
    dbname:'chat'
  },
  username:'root',
  pwd:'',
  dbname:'chat',
  sessionTime: 7 * 24 * 3600 * 1000,
}

module.exports = config;
